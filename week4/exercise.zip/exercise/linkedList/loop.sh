#!/bin/bash
./main 1000
